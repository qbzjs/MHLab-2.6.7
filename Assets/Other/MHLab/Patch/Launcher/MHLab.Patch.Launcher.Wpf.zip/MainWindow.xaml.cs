﻿using MHLab.Patch.Core.Client;
using MHLab.Patch.Core.Client.IO;
using MHLab.Patch.Core.Client.Progresses;
using MHLab.Patch.Core.IO;
using MHLab.Patch.Core.Utilities;
using MHLab.Patch.Launcher.Wpf.Localization;
using MHLab.Patch.Launcher.Wpf.Serializing;
using MHLab.Patch.Launcher.Wpf.Utilities;
using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using MHLab.Patch.Core;
using MHLab.Patch.Core.Logging;

namespace MHLab.Patch.Launcher.Wpf
{
    public partial class MainWindow : Window
    {
        private Repairer        _repairer;
        private Updater         _updater;
        private PatcherUpdater  _patcherUpdater;
        private UpdatingContext _context;
        private INetworkChecker _networkChecker;

        private Timer _timer;
        private int   _elapsed;

        private string _launcherExecutableName;
        private string _gameExecutableName;
        private string _gameName;
        private bool   _launchAnywayOnError;

        public MainWindow()
        {
            InitializeComponent();

            AppDomain.CurrentDomain.UnhandledException += (sender, e) => FatalExceptionObject(e.ExceptionObject);

            ErrorCloseButton.Click    += OnErrorClose_Click;
            ErrorContinueButton.Click += OnErrorContinue_Click;

            GenerateDebugReportButton.Click += GenerateDebugReportButton_Click;

            Initialize(CreateSettings());

            ResetComponents();
        }

        private ILauncherSettings CreateSettings()
        {
            _launcherExecutableName = "MHLab.Patch.Launcher.Wpf.exe";
            _gameName               = "YourGame";
            _gameExecutableName     = $"{_gameName}.exe";
            _launchAnywayOnError    = true;

            var settings = new LauncherSettings
            {
                RemoteUrl             = "http://localhost:8000/",
                PatchDownloadAttempts = 3,
                AppDataPath = FilesManager.SanitizePath(
                    PathsManager.Combine(PathsManager.GetSpecialPath(Environment.SpecialFolder.ApplicationData),
                                         _gameName)),
                RootPath = FilesManager.SanitizePath(DirectoriesManager.GetCurrentDirectory()),
#if DEBUG
                DebugMode = true,
#else
                DebugMode = false,
#endif
            };

            return settings;
        }

        private void Initialize(ILauncherSettings settings)
        {
            SoftwareVersionNumber.Content = $"v{settings.SoftwareVersion}";

            var progress = new Progress<UpdateProgress>();
            progress.ProgressChanged += UpdateProgressChanged;

            _context            = new UpdatingContext(settings, progress);
            _context.Logger     = new SimpleLogger(_context.FileSystem, settings.GetLogsFilePath(), settings.DebugMode);
            _context.Serializer = new JsonSerializer();
            
            _context.LocalizedMessages           =  new EnglishUpdaterLocalizedMessages();
            _context.Downloader                  =  new FileDownloader(_context.FileSystem);
            _context.Downloader.DownloadComplete += DownloadComplete;

            _context.OverrideSettings<SettingsOverride>((originalSettings, settingsOverride) =>
            {
                originalSettings.DebugMode              = settingsOverride.DebugMode;
                originalSettings.PatcherUpdaterSafeMode = settingsOverride.PatcherUpdaterSafeMode;
            });

            _networkChecker = new NetworkChecker();

            _repairer       = new Repairer(_context);
            _updater        = new Updater(_context);
            _patcherUpdater = new PatcherUpdater(_context);

            _context.RegisterUpdateStep(_patcherUpdater);
            _context.RegisterUpdateStep(_repairer);
            _context.RegisterUpdateStep(_updater);

            _context.Runner.PerformedStep += (sender, updater) =>
            {
                if (_context.IsDirty(out var reasons, out var data))
                {
                    var stringReasons = "";

                    foreach (var reason in reasons)
                    {
                        stringReasons += $"{reason}, ";
                    }

                    stringReasons = stringReasons.Substring(0, stringReasons.Length - 2);

                    _context.Logger.Debug(
                        $"Context is set to dirty: updater restart required. The files [{stringReasons}] have been replaced.");

                    if (data.Count > 0)
                    {
                        if (data[0] is UpdaterSafeModeDefinition)
                        {
                            var definition = (UpdaterSafeModeDefinition) data[0];
                            UpdateRestartNeeded(definition.ExecutableToRun);
                            return;
                        }
                    }

                    UpdateRestartNeeded();
                }
            };

            VersionLabel.Content = _context.GetLocalVersion();
        }

        private void DownloadComplete(object sender, EventArgs e)
        {
        }

        private void UpdateProgressChanged(object sender, UpdateProgress e)
        {
            MainProgressBar.Dispatcher.Invoke(() =>
            {
                var totalSteps = Math.Max(e.TotalSteps, 1);

                MainProgressBar.Minimum = 0;
                MainProgressBar.Maximum = totalSteps;
                MainProgressBar.Value   = e.CurrentSteps;

                ProgressPercentage.Content = $"{e.Percentage}%";

                SizeProgress.Content = FormatUtility.FormatSizeDecimal(e.CurrentSteps, 2) + "/" +
                                       FormatUtility.FormatSizeDecimal(e.TotalSteps, 2);
            });

            Log(e.StepMessage);
        }

        private void Log(string message)
        {
            MainLog.Dispatcher.Invoke(() => { MainLog.Content = message; });
        }

        private void ResetComponents()
        {
            MainProgressBar.Dispatcher.Invoke(() =>
            {
                ProgressPercentage.Content = "";
                DownloadSpeed.Content      = "";
                ElapsedTime.Content        = "";
                MainLog.Content            = "";
                SizeProgress.Content       = "";

                MainProgressBar.Value = 0;
            });
        }

        private void ShowDialog(string main, string detail)
        {
            MainErrorLabel.Dispatcher.Invoke(() =>
            {
                MainErrorLabel.Text   = main;
                DetailErrorLabel.Text = detail;

                ErrorCloseButton.Visibility    = Visibility.Visible;
                ErrorContinueButton.Visibility = Visibility.Visible;

                ErrorPanel.Visibility = Visibility.Visible;
            });
        }

        private void ShowCloseDialog(string main, string detail)
        {
            MainErrorLabel.Dispatcher.Invoke(() =>
            {
                MainErrorLabel.Text   = main;
                DetailErrorLabel.Text = detail;

                ErrorCloseButton.Visibility    = Visibility.Visible;
                ErrorContinueButton.Visibility = Visibility.Hidden;

                ErrorPanel.Visibility = Visibility.Visible;
            });
        }

        private void OnErrorClose_Click(object sender, RoutedEventArgs args)
        {
            ErrorPanel.Visibility = Visibility.Hidden;
            Environment.Exit(0);
        }

        private void OnErrorContinue_Click(object sender, RoutedEventArgs args)
        {
            ErrorPanel.Visibility = Visibility.Hidden;
            StartUpdateProcess();
        }

        private void OptionsOpenButton_Click(object sender, RoutedEventArgs e)
        {
            OptionsPanel.Visibility = Visibility.Visible;
        }

        private void OptionsCloseButton_Click(object sender, RoutedEventArgs e)
        {
            OptionsPanel.Visibility = Visibility.Hidden;
        }

        private void GenerateDebugReportButton_Click(object sender, RoutedEventArgs e)
        {
            var report = Debugger.GenerateDebugReport(_context.Settings, string.Empty, new JsonSerializer());

            _context.FileSystem.WriteAllTextToFile((FilePath)"debug_report_launcher.txt", report);
        }

        private void PlayDownloaderButton_Click(object sender, RoutedEventArgs e)
        {
            _context.Downloader.Resume();
        }

        private void PauseDownloaderButton_Click(object sender, RoutedEventArgs e)
        {
            _context.Downloader.Pause();
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            if (_context.FileSystem.IsDirectoryWritable((FilePath)_context.Settings.GetLogsDirectoryPath()))
            {
                StartUpdateProcess();
            }
            else
            {
                Log(_context.LocalizedMessages.LogsFileNotWritable);
                _context.Logger.Error(
                    null, "Updating process FAILED! The Launcher has not enough privileges to write into its folder!");
                ShowDialog(_context.LocalizedMessages.LogsFileNotWritable, _context.Settings.GetLogsFilePath());
            }
        }

        private void StartUpdateProcess()
        {
            try
            {
                _context.Logger.Info("Updating process STARTED!");

                Log(_context.LocalizedMessages.CheckingForNetworkAvailability);
                if (!_networkChecker.IsNetworkAvailable())
                {
                    Log(_context.LocalizedMessages.NotAvailableNetwork);
                    ShowCloseDialog(_context.LocalizedMessages.NotAvailableNetwork, string.Empty);
                    _context.Logger.Error(
                        null,
                        "Updating process FAILED! Network is not available or connectivity is low/weak... Check your connection!");
                    TryStartGameAnyway();
                    return;
                }

                Log(_context.LocalizedMessages.CheckingForServerAvailability);
                if (!_networkChecker.IsRemoteServiceAvailable(_context.Settings.GetRemoteBuildsIndexUrl(),
                                                              out var exception))
                {
                    Log(_context.LocalizedMessages.NotAvailableServers);
                    ShowCloseDialog(_context.LocalizedMessages.NotAvailableServers, string.Empty);
                    _context.Logger.Error(
                        exception,
                        "Updating process FAILED! Our servers are not responding... Wait some minutes and retry!");
                    _context.Logger.Debug(
                        $"The builds definition is used to determine if the server can be reached. Make sure to upload it at the correct location. Current check is performed at: {_context.Settings.GetRemoteBuildsIndexUrl()}");
                    TryStartGameAnyway();
                    return;
                }

                _context.Initialize();

                Task.Run(CheckForUpdates);
            }
            catch (Exception ex)
            {
                UpdateFailed(ex);
                TryStartGameAnyway();
            }
        }

        private void CheckForUpdates()
        {
            UpdateStarted();

            try
            {
                _context.Update();

                UpdateCompleted();
            }
            catch (Exception e)
            {
                UpdateFailed(e);
                TryStartGameAnyway();
            }
        }

        private void UpdateStarted()
        {
            _timer = new Timer((state) =>
                               {
                                   UpdateElapsedTime();

                                   _context.Downloader.DownloadSpeedMeter.Tick();

                                   UpdateDownloadSpeed();
                                   UpdateDownloadControlButtons();
                               },
                               null, TimeSpan.Zero, TimeSpan.FromSeconds(1)
            );

            Log(_context.LocalizedMessages.UpdateProcessProgressing);
        }

        private void UpdateElapsedTime()
        {
            _elapsed++;
            ElapsedTime.Dispatcher.Invoke(() =>
            {
                var minutes = _elapsed / 60;
                var seconds = _elapsed % 60;

                ElapsedTime.Content = string.Format("{0}:{1}", (minutes < 10) ? "0" + minutes : minutes.ToString(),
                                                    (seconds            < 10) ? "0" + seconds : seconds.ToString());
            });
        }

        private void UpdateDownloadSpeed()
        {
            DownloadSpeed.Dispatcher.Invoke(() =>
            {
                if (_context.Downloader.DownloadSpeedMeter.DownloadSpeed > 0)
                {
                    DownloadSpeed.Content = _context.Downloader.DownloadSpeedMeter.FormattedDownloadSpeed;
                }
                else
                {
                    DownloadSpeed.Content = string.Empty;
                }
            });
        }

        private void UpdateDownloadControlButtons()
        {
            PauseButton.Dispatcher.Invoke(() =>
            {
                if (_context.Downloader.DownloadSpeedMeter.DownloadSpeed > 0)
                {
                    UpdateDownloadControlButtonForDownloader(_context.Downloader);
                }
                else
                {
                    if (_context.Downloader.IsPaused)
                    {
                        PlayButton.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        PlayButton.Visibility = Visibility.Hidden;
                    }

                    PauseButton.Visibility = Visibility.Hidden;
                }
            });
        }

        private void UpdateDownloadControlButtonForDownloader(IDownloader downloader)
        {
            if (downloader.IsPaused)
            {
                PlayButton.Visibility  = Visibility.Visible;
                PauseButton.Visibility = Visibility.Hidden;
            }
            else
            {
                PlayButton.Visibility  = Visibility.Hidden;
                PauseButton.Visibility = Visibility.Visible;
            }
        }

        private void UpdateCompleted()
        {
            _timer.Dispose();
            Log(_context.LocalizedMessages.UpdateProcessCompleted);
            _context.Logger.Info("Updating process COMPLETED!");

            VersionLabel.Dispatcher.Invoke(() => { VersionLabel.Content = _context.GetLocalVersion(); });

            MainProgressBar.Dispatcher.Invoke(() =>
            {
                MainProgressBar.Minimum = 0;
                MainProgressBar.Maximum = 1;
                MainProgressBar.Value   = 1;

                ProgressPercentage.Content = "100%";
            });

            PauseButton.Dispatcher.Invoke(() =>
            {
                PlayButton.Visibility  = Visibility.Hidden;
                PauseButton.Visibility = Visibility.Hidden;
            });

            var launcherPath = _context.FileSystem.CombinePaths(_context.Settings.RootPath, _launcherExecutableName);

            EnsureExecutePrivileges(_context.FileSystem.CombinePaths(_context.Settings.GetGamePath(), _gameExecutableName).FullPath);
            EnsureExecutePrivileges(launcherPath.FullPath);

            try
            {
                _context.FileSystem.EnsureShortcutOnDesktop(launcherPath, _launcherExecutableName + " - Shortcut");
            }
            catch (Exception e)
            {
                _context.Logger.Warning($"Cannot create desktop shortcut: {e.Message}");
            }

            StartGame();
        }

        private void UpdateFailed(Exception e)
        {
            UpdateFailed(_context.LocalizedMessages.UpdateProcessFailed, e.GetType().ToString(), e.Message, e);
        }
        
        private void UpdateFailed(string mainLog, string dialogTitle, string dialogBody, Exception e)
        {
            _timer?.Dispose();
            ResetComponents();
            Log(mainLog);
            _context.Logger.Error(e, $"Updating process FAILED!");
            ShowDialog(dialogTitle, dialogBody);
        }

        private void UpdateRestartNeeded(string executableName = "")
        {
            Log(_context.LocalizedMessages.UpdateRestartNeeded);
            _context.Logger.Info("Updating process INCOMPLETE: restart is needed!");

            string filePath;

            if (!string.IsNullOrWhiteSpace(executableName))
            {
                filePath = _context.FileSystem.CombinePaths(_context.Settings.RootPath, executableName).FullPath;
            }
            else
            {
                filePath = _context.FileSystem.CombinePaths(_context.Settings.RootPath, _launcherExecutableName).FullPath;
            }

            try
            {
                ApplicationStarter.StartApplication(filePath, "");
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                _context.Logger.Error(null, $"Unable to start the Launcher at {filePath}.");
                UpdateFailed(ex);
            }
        }

        private void TryStartGameAnyway()
        {
            if (!_launchAnywayOnError) return;
            if (!_context.LocalVersionExists()) return;

            StartGame();
        }

        private void DragMoveMouseDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                if (e.ChangedButton == MouseButton.Left)
                    this.DragMove();
            }
            catch
            {
            }
        }

        private void FatalExceptionObject(object exceptionObject)
        {
            var exception = exceptionObject as Exception;
            if (exception == null)
            {
                exception = new NotSupportedException(
                    "Unhandled exception doesn't derive from System.Exception: "
                    + exceptionObject.ToString()
                );
            }

            HandleException(exception);
        }

        private void HandleException(Exception e)
        {
            _context?.Logger?.Error(e, "Updating process FAILED! An unhandled error occurred!");
        }

        private void EnsureExecutePrivileges(string filePath)
        {
            try
            {
                PrivilegesSetter.EnsureExecutePrivileges(filePath);
            }
            catch (Exception ex)
            {
                _context.Logger.Error(ex, $"Unable to set executing privileges on {filePath}.");
            }
        }

        private void StartGame()
        {
            var filePath = _context.FileSystem.CombinePaths(_context.Settings.GetGamePath(), _gameExecutableName).FullPath;

            try
            {
                ApplicationStarter.StartApplication(filePath, $"{_context.Settings.LaunchArgumentParameter}={_context.Settings.LaunchArgumentValue}");
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                _context.Logger.Error(null, $"Unable to start the application at {filePath}.");

                var mainError = _context.LocalizedMessages.UpdateUnableToStartTargetApplication;
                UpdateFailed(mainError, mainError, ex.Message, ex);
            }
        }
    }
}